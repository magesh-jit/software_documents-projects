<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Camera  photo</name>
   <tag></tag>
   <elementGuidId>aa4e5a50-11ac-4f5d-90f3-d0cec7cddffa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Camera &amp; photo')])[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Show products in category Camera &amp; photo&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d8a1e05d-476a-432b-999b-aefa2c26c565</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/camera-photo</value>
      <webElementGuid>8688b2bd-9a91-4392-9bb7-54698a4b9d2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Show products in category Camera &amp; photo</value>
      <webElementGuid>44d28412-38fd-46cc-a688-94ad2fc5da8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Camera &amp; photo </value>
      <webElementGuid>c1cd741e-b413-4d9a-8c17-556420157065</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;html-category-page&quot;]/body[1]/div[@class=&quot;master-wrapper-page&quot;]/div[@class=&quot;master-wrapper-content&quot;]/div[@class=&quot;master-column-wrapper&quot;]/div[@class=&quot;center-2&quot;]/div[@class=&quot;page category-page&quot;]/div[@class=&quot;page-body&quot;]/div[@class=&quot;category-grid sub-category-grid&quot;]/div[@class=&quot;item-grid&quot;]/div[@class=&quot;item-box&quot;]/div[@class=&quot;sub-category-item&quot;]/h2[@class=&quot;title&quot;]/a[1]</value>
      <webElementGuid>e764f746-f5e3-420b-91e8-8531272a3912</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Camera &amp; photo')])[4]</value>
      <webElementGuid>8b7f8d0d-7a62-4703-b93c-791b4fa17849</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Electronics'])[5]/following::a[1]</value>
      <webElementGuid>f4e6634f-5fbc-4848-a139-dc34a00db515</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View all'])[2]/following::a[1]</value>
      <webElementGuid>b77fc7d8-36a6-4117-8233-cd489c6ed80b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cell phones'])[4]/preceding::a[2]</value>
      <webElementGuid>fdc4ec8f-5538-4362-80f9-194c24b63885</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Others'])[4]/preceding::a[4]</value>
      <webElementGuid>3bd9666c-533f-45e9-b1b2-7995742db518</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/camera-photo')])[4]</value>
      <webElementGuid>90be890b-8974-4f1e-a252-304762023bea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2/a</value>
      <webElementGuid>4323b5c3-501f-45d7-874f-9a3d0b4e23f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/camera-photo' and @title = 'Show products in category Camera &amp; photo' and (text() = ' Camera &amp; photo ' or . = ' Camera &amp; photo ')]</value>
      <webElementGuid>435ed0f5-41e9-43eb-982d-3b9388bacc72</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
